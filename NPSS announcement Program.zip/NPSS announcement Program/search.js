//Function that will run when search button is clicked
function search() {

    //Selected grades
    var grade09S = [false];
    var grade10S = [false];
    var grade11S = [false];
    var grade12S = [false];
    var gradeAllS = [false];

    var genderMaleS = [false];
    var genderFemaleS = [false];
    var genderOtherS= [false];

    //Isolating the chosen grade(s)
    if (document.getElementById("SGrade9").checked) {
        grade09S[0] = true;
    }
    if (document.getElementById("SGrade10").checked) {
        grade10S[0] = true;
    }
    if (document.getElementById("SGrade11").checked) {
        grade11S[0] = true;
    }
    if (document.getElementById("SGrade12").checked) {
        grade12S[0] = true;
    }

    if ((!(grade09S[0]) && !(grade10S[0]) && !(grade11S[0]) && !(grade12S[0])) ||
    ((grade09S[0]) && (grade10S[0]) && (grade11S[0]) && (grade12S[0]))) {
        gradeAllS[0] = true;
    }

    //Isolating the chosen club
    var clubsS = [];
    clubsS[0] = document.getElementById("SClubs").value;

    //Setting the chosen genders to true
    if (document.getElementById("SMale").checked) {
        genderMaleS = [true];
    }
    if (document.getElementById("SFemale").checked) {
        genderFemaleS = [true];
    }
    if (document.getElementById("Sother").checked) {
        genderOtherS = [true];
   }
    //Information sent to local storage
    localStorage.setItem("studentGrade09Key", JSON.stringify(grade09S));
    localStorage.setItem("studentGrade10Key", JSON.stringify(grade10S));
    localStorage.setItem("studentGrade11Key", JSON.stringify(grade11S));
    localStorage.setItem("studentGrade12Key", JSON.stringify(grade12S));
    localStorage.setItem("studentGradeAllKey", JSON.stringify(gradeAllS));

    localStorage.setItem("studentClubKey", JSON.stringify(clubsS));

    localStorage.setItem("studentGenderMaleKey", JSON.stringify(genderMaleS));
    localStorage.setItem("studentGenderFemaleKey", JSON.stringify(genderFemaleS));
    localStorage.setItem("studentGenderOtherKey", JSON.stringify(genderOtherS));
    console.log(genderFemaleS)
}
