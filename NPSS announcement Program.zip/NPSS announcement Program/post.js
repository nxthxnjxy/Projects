//Arrays that store the input received from the teacher's announcement page
var grade09T = [];
var grade10T = [];
var grade11T = [];
var grade12T = [];
var gradeAllT = [];

var genderMaleT = [];
var genderFemaleT = [];
var genderOtherT = [];

var clubsT = [];

var contentT = [];

//Counter set to 0
var counter = 0;

//Function that will run when post button is clicked
function post() {
     save()
     //Setting the initial input as false for everything
     grade09T[counter] = false;
     grade10T[counter] = false;
     grade11T[counter] = false;
     grade12T[counter] = false;
     gradeAllT[counter] = false;

     genderMaleT[counter] = false;
     genderFemaleT[counter] = false;

     //Setting the chosen grades to true
     if (document.getElementById("Tgrade9").checked) {
          grade09T[counter] = true;
     }
     if (document.getElementById('Tgrade10').checked) {
          grade10T[counter] = true;
     }
     if (document.getElementById('Tgrade11').checked) {
          grade11T[counter] = true;
     }
     if (document.getElementById('Tgrade12').checked) {
          grade12T[counter] = true;
     }

     //Checking if all or none of the grades were selected
     if ((grade09T[counter] && grade10T[counter] && grade11T[counter] && grade12T[counter]) || (!grade09T && !grade10T && !grade11T && !grade12T)) {
          gradeAllT[counter] = true;
     }

     //Retrieving selected clubs
     clubsT[counter] = document.getElementById("Tclubs").value;

     //Setting the chosen genders to true
     if (genderMaleT[counter] = document.getElementById("Tboys").checked) {
          genderMaleT[counter] = true;
     }
     if (genderFemaleT[counter] = document.getElementById("Tgirls").checked) {
          genderFemaleT[counter] = true;
     }
     if (genderOtherT[counter] = document.getElementById("Tother").checked) {
          genderOtherT[counter] = true;
     }
     
     //Retrieving announcement content
     contentT[counter] = document.getElementById("Tcontent").value;

     console.log(contentT[counter])

     //Information sent to local storage
     localStorage.setItem("teacherGrade09Key", JSON.stringify(grade09T));
     localStorage.setItem("teacherGrade10Key", JSON.stringify(grade10T));
     localStorage.setItem("teacherGrade11Key", JSON.stringify(grade11T));
     localStorage.setItem("teacherGrade12Key", JSON.stringify(grade12T));
     localStorage.setItem("teacherGradeAllKey", JSON.stringify(gradeAllT));

     localStorage.setItem("teacherGenderMaleKey", JSON.stringify(genderMaleT));
     localStorage.setItem("teacherGenderFemaleKey", JSON.stringify(genderFemaleT));
     localStorage.setItem("teacherGenderOtherKey", JSON.stringify(genderOtherT));

     localStorage.setItem("teacherClubKey", JSON.stringify(clubsT));

     localStorage.setItem("teacherContentKey", JSON.stringify(contentT));
     
     counter++;

//Alert displayed after post button is clicked
     alert("Announcement was posted!")
}

//Function that will save previous announcements in the localStorage
function save() {

     if (JSON.parse(localStorage.getItem("teacherGrade09Key")) != null) {
          grade09T = JSON.parse(localStorage.getItem("teacherGrade09Key"));
          grade10T = JSON.parse(localStorage.getItem("teacherGrade10Key"));
          grade11T = JSON.parse(localStorage.getItem("teacherGrade11Key"));
          grade12T = JSON.parse(localStorage.getItem("teacherGrade12Key"));
          gradeAllT = JSON.parse(localStorage.getItem("teacherGradeAllKey"));

          clubsT = JSON.parse(localStorage.getItem("teacherClubKey"));

          genderMaleT = JSON.parse(localStorage.getItem("teacherGenderMaleKey"));
          genderFemaleT = JSON.parse(localStorage.getItem("teacherGenderFemaleKey"));
          genderOtherT = JSON.parse(localStorage.getItem("teacherGenderOtherKey"))

          contentT = JSON.parse(localStorage.getItem("teacherContentKey"));

          counter = grade09T.length;
     }
}