//Created arrays for both teacher and student inputs
var announcements = "";
var finalGender = [];
var finalGrade = [];

var teacherGrade09 = [];
var teacherGrade10 = [];
var teacherGrade11 = [];
var teacherGrade12 = [];
var teacherGradeAll = [];

var teacherClub = [];

var teacherMaleGender = [];
var teacherFemaleGender = [];
var teacherOtherGender = [];

var teacherContent = [];

var studentGrade09 = [];
var studentGrade10 = [];
var studentGrade11 = [];
var studentGrade12 = [];
var studentGradeAll = [];

var studentClub = [];
var studentMaleGender = [];
var studentFemaleGender = [];
var studentOtherGender = [];

//Function that will run when website is loaded
function displayResults() {

//Information being retrieved from local storage
    teacherContent = JSON.parse(localStorage.getItem("teacherContentKey"))

    teacherGrade09 = JSON.parse(localStorage.getItem("teacherGrade09Key"));
    teacherGrade10 = JSON.parse(localStorage.getItem("teacherGrade10Key"));
    teacherGrade11 = JSON.parse(localStorage.getItem("teacherGrade11Key"));
    teacherGrade12 = JSON.parse(localStorage.getItem("teacherGrade12Key"));
    teacherGradeAll = JSON.parse(localStorage.getItem("teacherGradeAllKey"));

    teacherClub = JSON.parse(localStorage.getItem("teacherClubKey"));

    teacherMaleGender = JSON.parse(localStorage.getItem("teacherGenderMaleKey"));
    teacherFemaleGender = JSON.parse(localStorage.getItem("teacherGenderFemaleKey"));
    teacherOtherGender = JSON.parse(localStorage.getItem("teacherGenderOtherKey"));

    studentGrade09 = JSON.parse(localStorage.getItem("studentGrade09Key"));
    studentGrade10 = JSON.parse(localStorage.getItem("studentGrade10Key"));
    studentGrade11 = JSON.parse(localStorage.getItem("studentGrade11Key"));
    studentGrade12 = JSON.parse(localStorage.getItem("studentGrade12Key"));
    studentGradeAll = JSON.parse(localStorage.getItem("studentGradeAllKey"));

    studentClub = JSON.parse(localStorage.getItem("studentClubKey"));

    studentMaleGender = JSON.parse(localStorage.getItem("studentGenderMaleKey"));
    studentFemaleGender = JSON.parse(localStorage.getItem("studentGenderFemaleKey"));
    studentOtherGender = JSON.parse(localStorage.getItem("studentGenderOtherKey"));

    console.log("G9: " + studentGrade09)

    //Created a for loop with an argument
    for (var i = 0; i < teacherMaleGender.length; i++) {
        
//Used an if statement to check for announcement matches
//Had an argument inside that would compare the student arrays with teacher arrays
//used the variable i to check the first index of the variables, all the way to the last index
        if ((((studentGrade09[0] == teacherGrade09[i] && studentGrade09[0] == true)) ||
            (studentGrade10[0] == teacherGrade10[i] && studentGrade10[0] == true) ||
            (studentGrade11[0] == teacherGrade11[i] && studentGrade11[0] == true) ||
            (studentGrade12[0] == teacherGrade12[i] && studentGrade12[0] == true) ||
            (studentGradeAll[0] == teacherGradeAll[i] && studentGradeAll[0] == true)) &&
            ((studentMaleGender[0] == teacherMaleGender[i] && studentMaleGender[0] == true) ||
            (studentFemaleGender[0] == teacherFemaleGender[i] && studentFemaleGender[0] == true) ||
            (studentOtherGender[0] == teacherOtherGender[i] && studentOtherGender[0] == true)) &&
            ((studentClub[0] == teacherClub[i]) || teacherClub[i] == "All Clubs" || (studentClub[0] == "All Clubs"))) {
            if (teacherGrade09[i]) {
                finalGrade.push(" Grade 9 ")
            }
            if (teacherGrade10[i]) {
                finalGrade.push(" Grade 10 ")
            }
            if (teacherGrade11[i]) {
                finalGrade.push(" Grade 11 ")
            }
            if (teacherGrade12[i]) {
                finalGrade.push(" Grade 12 ")
            }
            if (teacherMaleGender[i]) {
                finalGender.push(" Boys ")
            }
            if (teacherFemaleGender[i]) {
                finalGender.push(" Girls ")
            }
            if (teacherOtherGender[i]) {
                finalGender.push(" Other ")
            }

            announcements += finalGrade; 
            announcements += "<br>"
            announcements += teacherClub[i];
            announcements += "<br>"
            announcements += finalGender;
            announcements += "<br>"
            announcements += teacherContent[i];
            announcements += "<br>"
            announcements += "<br>"
            announcements += "<br>"

            finalGrade = [];
            finalGender = [];

//Results will display in this section of the HTML
            document.getElementById("searchResultsArea").innerHTML = announcements
        
//If theres no announcement match for the selected categories
        } else {
            console.log(i + ": result not found");
        }

    }

}