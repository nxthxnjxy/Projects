//Function that will run when login button is clicked
function login(){
    
//Receiving login information from HTML inputs
    var username = document.getElementById("Tusername").value;
    var password = document.getElementById("Tpassword").value;
    console.log("username: " + username)
    console.log("password: " + password)

//If login information matches this, it will take the user to the teacher announcement page
    if((username === ("Muhammad")) && (password === "846053")){
        location.href = "teacherAnnouncement.html"; 

//If login information doesn't matches this, it will display this alert
    }else{
        alert("Wrong Password or Username");
    }
}